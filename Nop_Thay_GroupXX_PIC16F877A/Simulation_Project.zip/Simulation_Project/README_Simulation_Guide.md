# CIRCUIT DESIGN & SIMULATION GUIDE (PROTEUS / SIMULIDE) — TOPIC #7: PWM MOTOR SPEED CONTROLLER (COMPONENT 5)

This guide provides the complete Bill of Materials (BOM), pin-by-pin schematic netlist, MCU property settings, and test procedure to simulate the **PWM DC Motor Speed Controller** using the compiled firmware: **`pwm_motor_controller.hex`** (`479` words, `__CONFIG = 0x3F31`).

---

## 1. Bill of Materials (Standard Proteus ISIS Component Names)

| # | RefDes | Proteus Component Name | Value / Specification | Function |
| :---: | :---: | :--- | :--- | :--- |
| 1 | `U1` | `PIC16F877A` | 40-pin PDIP, `Clock = 4MHz` | Main Microcontroller (CCP1 Hardware PWM) |
| 2 | `U2` | `L293D` | Dual H-Bridge Motor Driver IC | Drives DC Motor direction (`IN1/IN2`) & speed (`EN1 = PWM`) |
| 3 | `M1` | `MOTOR-DC` (or `MOTOR`) | `12V DC` (or `5V DC`) | DC Motor controlled by 1 kHz PWM & H-Bridge |
| 4 | `LCD1` | `LM016L` | 16×2 Character LCD (HD44780) | Displays PWM duty (`0–100%`), `CW/CCW`, `BTN/POT`, `RUN/STOP` |
| 5 | `RV1` | `POT-HG` | `10 kΩ` (across `+5V` and `GND`) | Analog speed potentiometer (`0%–99%` in `POT` mode) |
| 6 | `X1`, `C1–C2` | `CRYSTAL`, `CAP` | `4 MHz`, `2 × 22 pF` | External crystal oscillator (`_XT_OSC`) |
| 7 | `R1`, `SW_RST` | `RES`, `BUTTON` | `10 kΩ`, tactile switch | Active-low `~MCLR` Reset circuit |
| 8 | `SW1–SW5` | `BUTTON` | 5 switches to `GND` | `RUN/STOP (RB0)`, `+10% (RB1)`, `-10% (RB2)`, `DIR (RB3)`, `MODE (RB4)` |
| 9 | `LED_G`, `LED_R`, `LED_Y` | `LED-GREEN`, `LED-RED`, `LED-YELLOW` | With `3 × 330 Ω` (`R2–R4`) | `RUN` (Green), `STOP` (Red), `HIGH SPEED ≥ 80%` (Yellow) |
| 10 | `OSC1` | `OSCILLOSCOPE` *(Virtual Instrument)* | Channel A on `RC2/CCP1` | Measures exact `1.000 kHz` PWM frequency & duty cycle waveform |
| 11 | `POWER`, `GROUND` | `POWER (+5V, +12V)`, `GROUND` | `+5V` Logic, `+12V` Motor (`VS`) | Dual rails (or shared `+5V` for 5V DC motor) |

---

## 2. Schematic Wiring Table (Pin-to-Pin Netlist)

| Functional Block | PIC16F877A Pin | Connection Details |
| :--- | :--- | :--- |
| **Reset** | Pin 1 (`~MCLR/VPP`) | Pull up via `R1 (10 kΩ)` to `+5V`; connect `SW_RST` to `GND` |
| **Power** | Pins 11, 32 (`VDD`) / 12, 31 (`VSS`) | `+5V` / `GND` (hidden automatically in Proteus; add `0.1 µF` bypass caps for PCB) |
| **Oscillator** | Pin 13 (`OSC1`), Pin 14 (`OSC2`) | `4 MHz` crystal across pins; `22 pF` capacitor from each pin to `GND` |
| **Speed Pot** | Pin 2 (`RA0/AN0`) | Wiper of `POT-HG (RV1)` (`0% = 0V = 0%`, `100% = 5V = 99%` in `POT` mode) |
| **Buttons** | Pin 33 (`RB0/INT`) | `SW1 (RUN / STOP)` to `GND` *(uses internal `PORTB` pull-ups + External INT)* |
| **Buttons** | Pin 34 (`RB1`) | `SW2 (SPEED +10% in BTN mode)` to `GND` |
| **Buttons** | Pin 35 (`RB2`) | `SW3 (SPEED -10% in BTN mode)` to `GND` |
| **Buttons** | Pin 36 (`RB3`) | `SW4 (DIR: CW ↔ CCW)` to `GND` *(enabled by `_LVP_OFF` in `__CONFIG`)* |
| **Buttons** | Pin 37 (`RB4`) | `SW5 (MODE: BTN ↔ POT)` to `GND` |
| **L293D H-Bridge** | Pin 15 (`RC0`) → `L293D IN1` (Pin 2) | Direction Control A (`CW`: `IN1=1, IN2=0`) |
| **L293D H-Bridge** | Pin 16 (`RC1`) → `L293D IN2` (Pin 7) | Direction Control B (`CCW`: `IN1=0, IN2=1`) |
| **Hardware PWM** | Pin 17 (`RC2/CCP1`) → `L293D EN1` (Pin 1) | `1.000 kHz` Hardware PWM speed signal; also tap to **Proteus Oscilloscope Ch. A** |
| **L293D Power/Motor** | `L293D` Pins 3 & 6 (`OUT1`, `OUT2`) | Connect across `MOTOR-DC (M1)`; Pin 16 (`VSS`) = `+5V`, Pin 8 (`VS`) = `+12V` (or `+5V`), Pins 4,5,12,13 = `GND` |
| **Status LEDs** | Pin 18 (`RC3`), Pin 23 (`RC4`), Pin 24 (`RC5`) | Via `330 Ω` resistors to `LED_G (RUN)`, `LED_R (STOP)`, `LED_Y (HIGH ≥ 80%)` → `GND` |
| **LCD 16×2** | Pin 21 (`RD2`) → `RS` (LCD Pin 4) | Tie LCD `VSS` (Pin 1), `RW` (Pin 5), `VEE` (Pin 3) to `GND`; `VDD` (Pin 2) to `+5V` |
| **LCD 16×2** | Pin 22 (`RD3`) → `E` (LCD Pin 6) | Leave LCD `D0–D3` (Pins 7–10) unconnected |
| **LCD 16×2** | Pins 27–30 (`RD4–RD7`) | Connect directly to LCD `D4, D5, D6, D7` (LCD Pins 11–14) |

---

## 3. Proteus IC Configuration Checklist
1. Double-click `PIC16F877A` on the schematic:
   - **Program File:** Select `pwm_motor_controller.hex`
   - **Processor Clock Frequency:** Set to exactly **`4MHz`**
   - **Configuration Word:** Leave default (auto-loaded as `0x3F31` from `:02400E00313F40`)
2. Click **OK** → click **Play (Run Simulation)** and verify `TC01–TC06` below.

---

## 4. Verification Test Procedure (3-Minute Live Demo)

1. **TC01 – Power-On Default (`50%` PWM, `CW`, `BTN`):** Run simulation → LCD shows `PWM: 50% DIR:CW` / `MODE:BTN  RUN`; Green LED ON, Motor rotates clockwise, Oscilloscope on `RC2/CCP1` shows **`1.00 kHz` square wave with `50.0%` duty cycle (`0.50 ms` HIGH / `1.00 ms` period)**.
2. **TC02 – Button Speed Control & High-Speed Warning (`+10%` / `-10%`):** Press `SW2 (RB1)` three times → LCD updates `50% → 60% → 70% → 80%`, motor spins faster, Oscilloscope pulse widens to **`0.80 ms` (`80%`)**, and **Yellow LED (`RC5`)** illuminates (`≥ 80%`). Press `SW3 (RB2)` to step down.
3. **TC03 – Direction Reversal (`CW ↔ CCW`):** Press `SW4 (RB3)` → LCD switches `DIR:CW` → `DIR:CCW`, `RC0=0 / RC1=1`, and DC motor reverses rotation smoothly.
4. **TC04 – Instant Emergency `RUN / STOP` (`RB0/INT`):** Press `SW1 (RB0/INT)` → Hardware interrupt immediately sets `CCPR1L = 0` (`0%` PWM flat line on Oscilloscope), `IN1=IN2=0`, Motor stops, Red LED (`RC4`) turns ON, LCD shows `STOP`. Press `SW1` again to resume cleanly at the same speed.
5. **TC05 – Analog Potentiometer Mode (`BTN ↔ POT`):** Press `SW5 (RB4)` → LCD switches to `MODE:POT`. Rotate `RV1` from `25%` to `90%` → Within `0.2 s`, LCD tracks `PWM: 25%` → `PWM: 90%`, Oscilloscope duty updates smoothly via 10-bit `CCPR1L:DC1B`, and Yellow LED activates above `80%`.
6. **TC06 – EEPROM Persistence Across Reset:** Return to `MODE:BTN`, set speed to `70%` with `SW2`, press `SW_RST` (`~MCLR`) → After reboot, LCD automatically restores `PWM: 70%` from internal EEPROM (`0x00`).
