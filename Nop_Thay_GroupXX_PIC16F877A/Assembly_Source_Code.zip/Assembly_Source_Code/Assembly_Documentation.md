# ASSEMBLY LANGUAGE PROGRAMMING DOCUMENTATION — TOPIC #7: PWM MOTOR SPEED CONTROLLER (COMPONENT 2)

- **Source File:** `pwm_motor_controller.asm`
- **Compiled Firmware:** `pwm_motor_controller.hex` (Standard Intel HEX `INHX32M`, `__CONFIG = 0x3F31`, 64 records)
- **Listing File:** `pwm_motor_controller.lst` (**479 instruction words**, addresses `0x0000 – 0x01E1`, fits entirely within Page 0)
- **Target MCU & Clock:** Microchip `PIC16F877A` (40-Pin PDIP) @ `FOSC = 4 MHz` (`1 TCY = 1 µs`)

---

## 1. MCU Initialization and Register Configuration (`MAIN`)

| Step | Register & Bank | Value Written | Technical Purpose |
| :---: | :--- | :---: | :--- |
| 1 | `__CONFIG` (`2007h`) | `0x3F31` | `_XT_OSC` (4 MHz), `_WDT_OFF`, `_PWRTE_ON`, `_BODEN_OFF`, `_LVP_OFF` (frees `RB3` for Direction button), `_CP_OFF`. |
| 2 | `OPTION_REG` (Bank 1, `81h`) | `0x00` | `RBPU = 0` enables internal `PORTB` weak pull-ups for 5 push-buttons; `INTEDG = 0` sets `RB0/INT` to falling-edge trigger. |
| 3 | `ADCON1` (Bank 1, `9Fh`) | `0x0E` | `ADFM = 0` (left-justified 8-bit in `ADRESH`, Bank 0), `PCFG = 1110` (`RA0/AN0` Analog only; `AN1–AN7` Digital). |
| 4 | `TRISA–TRISE` (Bank 1) | `01h, 1Fh, 00h, 00h, 00h` | `RA0` Input (Potentiometer ADC); `RB0–RB4` Input (5 Buttons); `PORTC` Output (`IN1/IN2`, `CCP1` PWM, 3 LEDs); `PORTD` Output (4-bit LCD). |
| 5 | `PR2` (Bank 1, `92h`) | `0xF9` (`249`) | Sets Timer2 period register so `f_PWM = 1.000 kHz` with `1:4` prescaler (`1000` discrete 10-bit duty counts). |
| 6 | `PIE1` (Bank 1, `8Ch`) | `TMR1IE = 1` | Enables Timer1 overflow peripheral interrupt. |
| 7 | `CCP1CON`, `T2CON` (Bank 0) | `0x0C`, `0x05` | Configures `CCP1` (`RC2`) in Hardware PWM mode and starts Timer2 with `1:4` prescaler (`TMR2ON = 1`). |
| 8 | `ADCON0` (Bank 0, `1Fh`) | `0x41` | Selects `FOSC/8` (`TAD = 2.0 µs ≥ 1.6 µs`), Channel `AN0 (000)`, powers on ADC (`ADON = 1`). |
| 9 | `T1CON`, `TMR1H:L` (Bank 0) | `0x31`, `0xCF2C` | `1:8` prescaler, internal `FOSC/4` clock, preload `53,036` → overflows every `100 ms`. |
| 10 | `INTCON` (`0Bh`) | `GIE=PEIE=INTE=1` | Enables global interrupts, peripheral interrupts (Timer1), and external `RB0/INT` (instant RUN/STOP). |

---

## 2. Interrupt Service Routine Explanation (`ISR` at `0x0004`)
1. **Bank-Safe Context Saving (`DS39582C` Example 14-1, p. 154):** Because PIC16F877A has no `PUSH`/`POP` instructions and all 15 interrupt sources share vector `0x0004`, `W_TEMP (0x70)`, `STATUS_TEMP (0x71)`, and `PCLATH_TEMP (0x72)` reside in **Shared RAM (`0x70–0x7F`)**, mirrored across all 4 Banks. `SWAPF STATUS, W` preserves the `Z` flag before saving.
2. **Dual-Source Flag Polling:**
   - **Source 1 (`PIR1.TMR1IF == 1`):** Clears `TMR1IF`, briefly stops Timer1 to reload `0xCF2C` cleanly, restarts Timer1, and decrements `TICK_COUNT` (from `2` to `0`). Every `200 ms`, it sets `SYS_FLAGS.F_REFRESH` for non-blocking ADC/PWM/LCD updates.
   - **Source 2 (`INTCON.INTF == 1`):** Clears `INTF`, toggles `SYS_FLAGS.F_RUN` via `XORWF` (`RUN ↔ STOP`), and sets `F_REFRESH` for an immediate motor start/stop and LCD refresh.
3. **Context Restoration:** Restores `PCLATH`, `STATUS` (via `SWAPF`), and `W` (using two `SWAPF` instructions to preserve `Z`), then exits via `RETFIE`.

---

## 3. Core Algorithms and Hardware Interaction

1. **Exact 10-bit Hardware PWM Duty Calculation (`UPDATE_PWM_HW`):**
   - With `PR2 = 249` and `TMR2 Prescaler = 1:4`, total 10-bit PWM resolution is `4 × (PR2 + 1) = 1,000` counts at `1.000 kHz`.
   - For any integer percentage `ACTIVE_DUTY (0..100%)`, exact 10-bit counts = `ACTIVE_DUTY × 10`:
     - `CCPR1L = (ACTIVE_DUTY << 1) + (ACTIVE_DUTY >> 1) = floor(ACTIVE_DUTY × 2.5)` (`0..250`, zero 8-bit overflow).
     - `CCP1CON<5:4> (DC1B1:0)` = `00` if `ACTIVE_DUTY` is even (`0x0C`), or `10` (`+2` counts) if odd (`0x2C`).
   - Verified across all **101/101** duty percentages (`0%..100%`) with **0.0% rounding error**. When `F_RUN = 0` (STOP), `CCPR1L = 0` forces `0%` duty.
2. **Software 8×8 Potentiometer Scaling (`CALC_POT_PCT`):**
   - In **POT** mode (`F_POT_MODE = 1`), an 8-iteration shift-and-add routine multiplies `ADC_RAW (0..255)` by `100` and takes high byte `MUL_H = floor((ADC_RAW × 100) / 256)`, mapping `0..255` smoothly to `0..99%`.
3. **Anti-RMW Output Stage (`UPDATE_OUTPUTS`):**
   - H-Bridge direction lines (`RC0 = IN1`, `RC1 = IN2`) and LED indicators (`RC3` Green RUN, `RC4` Red STOP, `RC5` Yellow High-Speed `≥ 80%`) are assembled in RAM shadow register `PORTC_IMG` and written atomically via `MOVWF PORTC` (hardware `CCP1` on `RC2` overrides the pin driver cleanly).
4. **EEPROM Speed Persistence (`EEPROM_LOAD_SPEED` & `EEPROM_SAVE_SPEED`):**
   - Adjusting preset speed via `RB1` (`+10%`) or `RB2` (`-10%`) in `BTN` mode writes the new value to EEPROM (`0x00`) using the mandatory `0x55 → EECON2`, `0xAA → EECON2`, `BSF EECON1, WR` unlock sequence with `GIE = 0`. Blank EEPROM (`0xFF`) safely defaults to `50%`.
5. **Hardware Stack Safety Verification:**
   - Worst-case nesting: `MAIN_LOOP → UPDATE_LCD (1) → LCD_PRINT_3DIG (2) → LCD_DATA (3) → LCD_NIBBLE_CMD / DELAY_2MS (4)`. Adding an asynchronous ISR yields **5 / 8 hardware stack levels maximum**, leaving 3 levels of safety margin.
