; ============================================================================
; PROJECT:  TOPIC #7 — PWM DC MOTOR SPEED CONTROLLER (PIC16F877A)
; MCU:      Microchip PIC16F877A (40-Pin PDIP) @ Fosc = 4 MHz (1 TCY = 1 us)
; COMPILER: MPASM / gpasm / PIC16F877A Python Mini Assembler (100% Compatible)
;
; PERIPHERALS USED (5 Hardware Peripherals >= 3 Required):
;   1. CCP1 Hardware PWM + Timer2 (RC2/CCP1)      -> 1.000 kHz, 10-bit PWM
;                                                    (PR2 = 249, Prescaler 1:4)
;   2. ADC 10-bit (AN0/RA0, left-justified 8-bit) -> Analog Speed Potentiometer
;   3. Timer1 (16-bit) + Interrupt (TMR1IF)       -> 100 ms tick / 200 ms refresh
;   4. External Interrupt (RB0/INT, falling edge) -> Instant RUN / STOP Toggle
;   5. GPIO (PORTB, PORTC, PORTD) + Internal Data EEPROM (256B, addr 0x00)
;                                                 -> L293D H-Bridge, 16x2 LCD,
;                                                    Buttons, LEDs, Speed Memory
;
; PIN ASSIGNMENT (40-Pin PDIP):
;   RA0/AN0  (Pin 2)  : Analog Speed Potentiometer (0V = 0%, 5V = 99% in POT mode)
;   RB0/INT  (Pin 33) : RUN / STOP Button (External Interrupt, falling edge)
;   RB1      (Pin 34) : SPEED UP (+10% in BTN mode, auto-saved to EEPROM)
;   RB2      (Pin 35) : SPEED DOWN (-10% in BTN mode, auto-saved to EEPROM)
;   RB3      (Pin 36) : DIRECTION Toggle (CW <-> CCW; freed via _LVP_OFF)
;   RB4      (Pin 37) : MODE Toggle (BTN Preset <-> POT Analog)
;   RC0      (Pin 15) : H-Bridge IN1 (CW: IN1=1, IN2=0; CCW: IN1=0, IN2=1)
;   RC1      (Pin 16) : H-Bridge IN2
;   RC2/CCP1 (Pin 17) : Hardware PWM Output (1 kHz -> L293D EN1)
;   RC3      (Pin 18) : Green LED (Motor RUNNING)
;   RC4      (Pin 23) : Red LED (Motor STOPPED)
;   RC5      (Pin 24) : Yellow LED (High-Speed Warning >= 80%)
;   RD2      (Pin 21) : LCD RS
;   RD3      (Pin 22) : LCD EN (LCD RW tied to GND)
;   RD4-RD7  (27-30)  : LCD Data Bus D4-D7 (4-bit interface)
;   OSC1/2   (13-14)  : 4 MHz Crystal + 2x 22 pF capacitors
;   ~MCLR    (Pin 1)  : Reset RC circuit (10k pull-up + Reset button)
; ============================================================================

        LIST        P=16F877A
        #include    <p16f877a.inc>
        ERRORLEVEL  -302

        ; Configuration Word (0x2007): 4 MHz XT Osc, WDT OFF, PWRTE ON,
        ; BOR OFF, LVP OFF (frees RB3 for DIR button), Code Protect OFF -> 0x3F31
        __CONFIG    _CP_OFF & _DEBUG_OFF & _WRT_OFF & _CPD_OFF & _LVP_OFF & _BODEN_OFF & _PWRTE_ON & _WDT_OFF & _XT_OSC

; ============================================================================
; CONSTANTS & BIT DEFINITIONS
; ============================================================================
STEP_DUTY       EQU     0x0A        ; 10% speed step for UP/DOWN buttons
MIN_DUTY        EQU     0x00        ; Minimum duty cycle = 0%
MAX_DUTY        EQU     0x64        ; Maximum duty cycle = 100%
DEFAULT_DUTY    EQU     0x32        ; Default saved speed = 50%
HIGH_SPEED_PCT  EQU     0x50        ; High-speed warning LED threshold = 80%
EEPROM_SPD_ADDR EQU     0x00        ; EEPROM address storing BTN-mode speed

; Hardware PWM (CCP1 + Timer2) @ Fosc = 4 MHz, Timer2 Prescaler = 1:4:
; PWM Period = (PR2 + 1) * 4 * Tosc * Prescaler = 250 * 4 * 0.25us * 4 = 1000 us
; PWM Frequency = 1.000 kHz, 10-bit resolution = 4 * (PR2 + 1) = 1000 counts
PWM_PR2_VAL     EQU     0xF9        ; PR2 = 249 -> exact 1.000 kHz PWM
T2CON_PWM_ON    EQU     0x05        ; TMR2ON = 1 (bit 2), Prescaler 1:4 (01)
CCP1_PWM_EVEN   EQU     0x0C        ; PWM mode (1100), DC1B1:0 = 00
CCP1_PWM_ODD    EQU     0x2C        ; PWM mode (1100), DC1B1:0 = 10 (+2 counts)

; Timer1 preload for exact 100 ms @ 4 MHz, Prescaler 1:8:
; Fcy = 1 MHz -> T1clk = 125 kHz -> 12,500 counts -> 65536 - 12500 = 53036 = 0xCF2C
TMR1H_PRELOAD   EQU     0xCF
TMR1L_PRELOAD   EQU     0x2C
REFRESH_TICKS   EQU     0x02        ; 2 x 100 ms = 200 ms refresh interval

; Output bit positions on PORTC (RC2/CCP1 is driven by hardware PWM module)
IN1_BIT         EQU     0           ; RC0: H-Bridge IN1
IN2_BIT         EQU     1           ; RC1: H-Bridge IN2
LED_RUN_BIT     EQU     3           ; RC3: Green LED (Running)
LED_STOP_BIT    EQU     4           ; RC4: Red LED (Stopped)
LED_HI_BIT      EQU     5           ; RC5: Yellow LED (High Speed >= 80%)

; LCD control bits on PORTD
LCD_RS_BIT      EQU     2           ; RD2
LCD_EN_BIT      EQU     3           ; RD3

; System flag bits in SYS_FLAGS
F_REFRESH       EQU     0           ; Bit 0: 1 = 200 ms elapsed, update ADC/PWM/LCD
F_RUN           EQU     1           ; Bit 1: 1 = Motor RUNNING, 0 = STOPPED
F_DIR_CCW       EQU     2           ; Bit 2: 0 = CW, 1 = CCW
F_POT_MODE      EQU     3           ; Bit 3: 0 = BTN preset mode, 1 = POT analog mode

; ============================================================================
; RAM VARIABLES (Bank 0: 0x20-0x6F, Shared RAM: 0x70-0x7F)
; ============================================================================
        CBLOCK  0x20
            SYS_FLAGS               ; System status flags
            TICK_COUNT              ; 100 ms tick divider (counts down from 2)
            ADC_RAW                 ; 8-bit ADC reading (0..255 from ADRESH)
            BTN_DUTY                ; Saved button-mode duty cycle (0..100%)
            ACTIVE_DUTY             ; Active PWM duty cycle (0..100%)
            PWM_TEMP                ; Scratchpad for exact 10-bit PWM math
            MUL_A                   ; Multiplier operand A (ADC_RAW)
            MUL_B                   ; Multiplier operand B (100)
            MUL_H                   ; 16-bit product high byte (= (A*B)/256)
            MUL_L                   ; 16-bit product low byte
            BIT_CNT                 ; Loop counter for 8x8 multiplication
            BCD_HUND                ; Hundreds digit for LCD (0 or 1)
            BCD_TENS                ; Tens digit for LCD
            BCD_ONES                ; Ones digit for LCD
            LCD_TEMP                ; Temporary byte for LCD 4-bit send
            STR_IDX                 ; String table index
            DLY_1                   ; Delay loop counter 1
            DLY_2                   ; Delay loop counter 2
            EE_VAL                  ; Temporary value for EEPROM write
            PORTC_IMG               ; Shadow register for PORTC (prevents RMW)
        ENDC

        ; Shared RAM (0x70-0x7F): Accessible from ALL 4 Banks for safe ISR context save
        CBLOCK  0x70
            W_TEMP
            STATUS_TEMP
            PCLATH_TEMP
        ENDC

; ============================================================================
; RESET & INTERRUPT VECTORS
; ============================================================================
        ORG     0x0000
        GOTO    MAIN                ; Jump to initialization routine

        ORG     0x0004
; ----------------------------------------------------------------------------
; INTERRUPT SERVICE ROUTINE (ISR) — Handles Timer1 (100ms) & RB0/INT (RUN/STOP)
; Context saving follows Microchip DS39582C Example 14-1 (p. 154)
; ----------------------------------------------------------------------------
ISR:
        MOVWF   W_TEMP              ; Save W into Shared RAM (bank-independent)
        SWAPF   STATUS, W           ; Swap STATUS into W without affecting Z flag
        CLRF    STATUS              ; Switch to Bank 0
        MOVWF   STATUS_TEMP         ; Save STATUS
        MOVF    PCLATH, W
        MOVWF   PCLATH_TEMP         ; Save PCLATH
        CLRF    PCLATH              ; Select Page 0

        ; --- Check Source 1: Timer1 Overflow Interrupt (100 ms) ---
        BTFSS   PIR1, TMR1IF
        GOTO    ISR_CHK_INT0

        BCF     PIR1, TMR1IF        ; Clear Timer1 interrupt flag in software
        BCF     T1CON, TMR1ON       ; Stop Timer1 briefly to reload cleanly
        MOVLW   TMR1H_PRELOAD
        MOVWF   TMR1H
        MOVLW   TMR1L_PRELOAD
        MOVWF   TMR1L
        BSF     T1CON, TMR1ON       ; Restart Timer1

        DECFSZ  TICK_COUNT, F       ; 2 ticks x 100 ms = 200 ms?
        GOTO    ISR_CHK_INT0
        MOVLW   REFRESH_TICKS
        MOVWF   TICK_COUNT          ; Reload 2-tick divider
        BSF     SYS_FLAGS, F_REFRESH ; Signal main loop to refresh PWM & LCD

        ; --- Check Source 2: External Interrupt RB0/INT (RUN <-> STOP) ---
ISR_CHK_INT0:
        BTFSS   INTCON, INTF
        GOTO    ISR_EXIT

        BCF     INTCON, INTF        ; Clear External Interrupt flag
        MOVLW   0x02                ; Mask for F_RUN (bit 1)
        XORWF   SYS_FLAGS, F        ; Toggle Motor RUN (1) <-> STOP (0)
        BSF     SYS_FLAGS, F_REFRESH ; Trigger immediate PWM/LCD update

ISR_EXIT:
        MOVF    PCLATH_TEMP, W      ; Restore PCLATH
        MOVWF   PCLATH
        SWAPF   STATUS_TEMP, W      ; Restore original STATUS & Bank
        MOVWF   STATUS
        SWAPF   W_TEMP, F           ; Restore W without corrupting Z flag
        SWAPF   W_TEMP, W
        RETFIE                      ; Re-enable GIE and pop PC from Stack

; ============================================================================
; MAIN INITIALIZATION
; ============================================================================
MAIN:
        ; --- Configure Bank 1 Registers ---
        BSF     STATUS, RP0         ; Select Bank 1
        BCF     STATUS, RP1

        MOVLW   0x00                ; RBPU=0 (PORTB internal pull-ups ON), INTEDG=0 (falling edge)
        MOVWF   OPTION_REG

        MOVLW   0x0E                ; ADFM=0 (left-justified 8-bit in ADRESH), AN0 Analog only
        MOVWF   ADCON1

        MOVLW   0x01                ; RA0 = Input (Analog POT); RA1-RA5 = Output
        MOVWF   TRISA
        MOVLW   0x1F                ; RB0-RB4 = Input (5 Control Buttons); RB5-RB7 = Output
        MOVWF   TRISB
        CLRF    TRISC               ; RC0-RC1 (IN1/2), RC2 (CCP1 PWM), RC3-RC5 (LEDs) = Output
        CLRF    TRISD               ; RD2-RD7 (16x2 LCD 4-bit) = Output
        CLRF    TRISE               ; PORTE = Output

        MOVLW   PWM_PR2_VAL         ; PR2 = 249 -> 1.000 kHz PWM @ 4 MHz (TMR2 1:4)
        MOVWF   PR2

        CLRF    PIE1
        BSF     PIE1, TMR1IE        ; Enable Timer1 overflow interrupt

        ; --- Configure Bank 0 Registers ---
        BCF     STATUS, RP0         ; Return to Bank 0
        CLRF    PORTA
        CLRF    PORTB
        CLRF    PORTC
        CLRF    PORTD
        CLRF    PORTC_IMG

        ; Initialize Hardware PWM (CCP1 + Timer2) at 0% duty initially
        CLRF    CCPR1L
        MOVLW   CCP1_PWM_EVEN       ; CCP1CON = 0x0C (PWM mode, DC1B1:0 = 00)
        MOVWF   CCP1CON
        MOVLW   T2CON_PWM_ON        ; Timer2 ON, Prescaler 1:4
        MOVWF   T2CON

        ; Initialize ADC: Fosc/8 (TAD = 2 us >= 1.6 us), Channel AN0, ADON = 1
        MOVLW   0x41
        MOVWF   ADCON0

        ; Initialize System State Variables
        CLRF    SYS_FLAGS
        BSF     SYS_FLAGS, F_RUN    ; Start in RUNNING state (CW, BTN mode)
        BSF     SYS_FLAGS, F_REFRESH ; Force immediate first update
        MOVLW   REFRESH_TICKS
        MOVWF   TICK_COUNT

        ; Load saved button-mode duty cycle from internal EEPROM (0x00)
        CALL    EEPROM_LOAD_SPEED
        MOVF    BTN_DUTY, W
        MOVWF   ACTIVE_DUTY

        ; Initialize 16x2 LCD in 4-bit mode
        CALL    LCD_INIT

        ; Initialize Timer1: 1:8 Prescaler, Internal Clock (Fosc/4), 100 ms reload
        MOVLW   TMR1H_PRELOAD
        MOVWF   TMR1H
        MOVLW   TMR1L_PRELOAD
        MOVWF   TMR1L
        BCF     PIR1, TMR1IF
        MOVLW   0x31                ; T1CKPS=11 (1:8), TMR1CS=0, TMR1ON=1
        MOVWF   T1CON

        ; Enable Global, Peripheral (Timer1), and External RB0/INT Interrupts
        BCF     INTCON, INTF
        BSF     INTCON, INTE
        BSF     INTCON, PEIE
        BSF     INTCON, GIE

; ============================================================================
; MAIN APPLICATION LOOP (NON-BLOCKING)
; ============================================================================
MAIN_LOOP:
        CALL    CHECK_BUTTONS       ; Poll RB1 (+10%), RB2 (-10%), RB3 (DIR), RB4 (MODE)

        BTFSS   SYS_FLAGS, F_REFRESH ; Wait for 200 ms Timer1 tick or RB0/INT event
        GOTO    MAIN_LOOP
        BCF     SYS_FLAGS, F_REFRESH

        ; Determine active duty cycle based on Mode (BTN vs POT)
        BTFSS   SYS_FLAGS, F_POT_MODE
        GOTO    USE_BTN_SPEED

        ; POT Mode: Sample RA0/AN0 and scale 0..255 -> 0..99%
        CALL    READ_ADC_AN0
        CALL    CALC_POT_PCT        ; Result stored in ACTIVE_DUTY (0..99%)
        GOTO    APPLY_STAGE

USE_BTN_SPEED:
        MOVF    BTN_DUTY, W
        MOVWF   ACTIVE_DUTY

APPLY_STAGE:
        CALL    UPDATE_PWM_HW       ; Update 10-bit CCPR1L + CCP1CON<5:4>
        CALL    UPDATE_OUTPUTS      ; Update H-Bridge IN1/IN2 & Status LEDs (anti-RMW)
        CALL    UPDATE_LCD          ; Refresh 16x2 LCD display
        GOTO    MAIN_LOOP

; ============================================================================
; SUBROUTINE: CHECK_BUTTONS
;   RB1 = Speed +10% (BTN mode, saved to EEPROM)
;   RB2 = Speed -10% (BTN mode, saved to EEPROM)
;   RB3 = Direction Toggle (CW <-> CCW)
;   RB4 = Mode Toggle (BTN <-> POT)
; ============================================================================
CHECK_BUTTONS:
        ; --- Check RB1: SPEED UP (+10% in BTN mode) ---
        BTFSC   PORTB, 1            ; Active-low button pressed?
        GOTO    CHK_RB2
        CALL    DELAY_50MS          ; Debounce 50 ms
        BTFSC   PORTB, 1
        GOTO    CHK_RB2

        BTFSC   SYS_FLAGS, F_POT_MODE ; Ignore UP/DOWN in POT mode
        GOTO    WAIT_RB1_REL

        MOVLW   STEP_DUTY           ; +10%
        ADDWF   BTN_DUTY, W
        MOVWF   PWM_TEMP
        ; Clamp to MAX_DUTY (100%): if PWM_TEMP > 100 -> set 100
        MOVLW   MAX_DUTY
        SUBWF   PWM_TEMP, W         ; W = PWM_TEMP - 100; C=1 if PWM_TEMP >= 100
        BTFSC   STATUS, C
        GOTO    CLAMP_MAX_SPD
        MOVF    PWM_TEMP, W
        GOTO    STORE_UP_SPD
CLAMP_MAX_SPD:
        MOVLW   MAX_DUTY
STORE_UP_SPD:
        MOVWF   BTN_DUTY
        CALL    EEPROM_SAVE_SPEED   ; Persist new speed in EEPROM
        BSF     SYS_FLAGS, F_REFRESH

WAIT_RB1_REL:
        BTFSS   PORTB, 1
        GOTO    WAIT_RB1_REL
        CALL    DELAY_50MS

        ; --- Check RB2: SPEED DOWN (-10% in BTN mode) ---
CHK_RB2:
        BTFSC   PORTB, 2
        GOTO    CHK_RB3
        CALL    DELAY_50MS
        BTFSC   PORTB, 2
        GOTO    CHK_RB3

        BTFSC   SYS_FLAGS, F_POT_MODE ; Ignore UP/DOWN in POT mode
        GOTO    WAIT_RB2_REL

        MOVLW   STEP_DUTY           ; Check if BTN_DUTY < 10
        SUBWF   BTN_DUTY, W         ; W = BTN_DUTY - 10; C=0 if borrow (< 10)
        BTFSS   STATUS, C
        CLRW                        ; Clamp to 0% (MIN_DUTY)
        MOVWF   BTN_DUTY
        CALL    EEPROM_SAVE_SPEED   ; Persist new speed in EEPROM
        BSF     SYS_FLAGS, F_REFRESH

WAIT_RB2_REL:
        BTFSS   PORTB, 2
        GOTO    WAIT_RB2_REL
        CALL    DELAY_50MS

        ; --- Check RB3: DIRECTION TOGGLE (CW <-> CCW) ---
CHK_RB3:
        BTFSC   PORTB, 3
        GOTO    CHK_RB4
        CALL    DELAY_50MS
        BTFSC   PORTB, 3
        GOTO    CHK_RB4

        MOVLW   0x04                ; Mask for F_DIR_CCW (bit 2)
        XORWF   SYS_FLAGS, F        ; Toggle CW <-> CCW
        BSF     SYS_FLAGS, F_REFRESH

WAIT_RB3_REL:
        BTFSS   PORTB, 3
        GOTO    WAIT_RB3_REL
        CALL    DELAY_50MS

        ; --- Check RB4: MODE TOGGLE (BTN <-> POT) ---
CHK_RB4:
        BTFSC   PORTB, 4
        RETURN
        CALL    DELAY_50MS
        BTFSC   PORTB, 4
        RETURN

        MOVLW   0x08                ; Mask for F_POT_MODE (bit 3)
        XORWF   SYS_FLAGS, F        ; Toggle BTN <-> POT
        BSF     SYS_FLAGS, F_REFRESH

WAIT_RB4_REL:
        BTFSS   PORTB, 4
        GOTO    WAIT_RB4_REL
        CALL    DELAY_50MS
        RETURN

; ============================================================================
; SUBROUTINE: READ_ADC_AN0
;   Waits >= 25 us acquisition time (TACQ > 19.72 us per DS39582C Eq. 11-1),
;   starts conversion, polls GO/DONE, and stores left-justified 8-bit ADRESH.
; ============================================================================
READ_ADC_AN0:
        MOVLW   0x08                ; 8 x 3 us + overhead ~ 28 us acquisition wait
        MOVWF   DLY_1
ADC_ACQ_LOOP:
        DECFSZ  DLY_1, F
        GOTO    ADC_ACQ_LOOP

        BSF     ADCON0, GO          ; Start A/D conversion
ADC_WAIT:
        BTFSC   ADCON0, GO          ; Poll until hardware clears GO/DONE
        GOTO    ADC_WAIT

        MOVF    ADRESH, W           ; Bank 0: Read 8 MSBs (0..255)
        MOVWF   ADC_RAW
        RETURN

; ============================================================================
; SUBROUTINE: CALC_POT_PCT
;   Computes ACTIVE_DUTY = (ADC_RAW * 100) / 256 using 8x8 shift-and-add
;   multiplication (no hardware multiplier on PIC16F877A).
;   Maps ADC_RAW (0..255) cleanly to 0..99%.
; ============================================================================
CALC_POT_PCT:
        MOVF    ADC_RAW, W
        MOVWF   MUL_A
        MOVLW   0x64                ; Multiplier B = 100 decimal
        MOVWF   MUL_B
        CLRF    MUL_H
        CLRF    MUL_L
        MOVLW   0x08
        MOVWF   BIT_CNT

MUL_LOOP:
        RRF     MUL_B, F            ; Shift LSB of multiplier into Carry
        BTFSS   STATUS, C
        GOTO    MUL_NO_ADD
        MOVF    MUL_A, W
        ADDWF   MUL_H, F            ; Add multiplicand to high byte
MUL_NO_ADD:
        RRF     MUL_H, F            ; Shift 16-bit product right (Carry enters MSB)
        RRF     MUL_L, F
        DECFSZ  BIT_CNT, F
        GOTO    MUL_LOOP

        MOVF    MUL_H, W            ; High byte = floor((ADC_RAW * 100) / 256)
        MOVWF   ACTIVE_DUTY
        RETURN

; ============================================================================
; SUBROUTINE: UPDATE_PWM_HW
;   Loads exact 10-bit PWM duty cycle into CCPR1L and CCP1CON<5:4> for PR2=249:
;     10-bit counts = ACTIVE_DUTY * 10  (0..1000)
;     CCPR1L        = (ACTIVE_DUTY * 2) + (ACTIVE_DUTY / 2) = floor(DUTY*2.5)
;     CCP1CON<5:4>  = 00 if ACTIVE_DUTY is even, 10 (+2) if ACTIVE_DUTY is odd
;   If motor is STOPPED (F_RUN = 0), forces 0% duty cycle cleanly.
; ============================================================================
UPDATE_PWM_HW:
        BTFSS   SYS_FLAGS, F_RUN    ; Motor running?
        GOTO    PWM_FORCE_ZERO

        ; Compute CCPR1L = (ACTIVE_DUTY << 1) + (ACTIVE_DUTY >> 1)
        BCF     STATUS, C
        RLF     ACTIVE_DUTY, W      ; W = ACTIVE_DUTY * 2 (0..200, no overflow)
        MOVWF   PWM_TEMP
        BCF     STATUS, C
        RRF     ACTIVE_DUTY, W      ; W = ACTIVE_DUTY / 2 (0..50)
        ADDWF   PWM_TEMP, W         ; W = floor(ACTIVE_DUTY * 2.5) (0..250)
        MOVWF   CCPR1L

        ; Set lower 2 bits DC1B1:0 based on parity of ACTIVE_DUTY
        BTFSC   ACTIVE_DUTY, 0      ; Odd percentage?
        GOTO    PWM_SET_ODD
        MOVLW   CCP1_PWM_EVEN       ; Even -> DC1B1:0 = 00
        MOVWF   CCP1CON
        RETURN

PWM_SET_ODD:
        MOVLW   CCP1_PWM_ODD        ; Odd  -> DC1B1:0 = 10 (+2 counts = +0.2%)
        MOVWF   CCP1CON
        RETURN

PWM_FORCE_ZERO:
        CLRF    CCPR1L
        MOVLW   CCP1_PWM_EVEN
        MOVWF   CCP1CON
        RETURN

; ============================================================================
; SUBROUTINE: UPDATE_OUTPUTS (Anti-RMW Shadow Register Method)
;   Composes H-Bridge IN1/IN2 and LEDs in PORTC_IMG, then writes PORTC once.
;   (RC2/CCP1 hardware PWM output is unaffected by PORTC latch writes.)
; ============================================================================
UPDATE_OUTPUTS:
        CLRF    PORTC_IMG

        BTFSS   SYS_FLAGS, F_RUN    ; Running or Stopped?
        GOTO    OUT_STOPPED

        ; Motor RUNNING: Green LED ON, set H-Bridge direction
        BSF     PORTC_IMG, LED_RUN_BIT
        BTFSC   SYS_FLAGS, F_DIR_CCW
        GOTO    OUT_CCW
        BSF     PORTC_IMG, IN1_BIT  ; CW: IN1 = 1, IN2 = 0
        GOTO    OUT_CHK_HIGH
OUT_CCW:
        BSF     PORTC_IMG, IN2_BIT  ; CCW: IN1 = 0, IN2 = 1

OUT_CHK_HIGH:
        ; Turn on Yellow High-Speed LED if ACTIVE_DUTY >= 80%
        MOVLW   HIGH_SPEED_PCT
        SUBWF   ACTIVE_DUTY, W      ; C = 1 if ACTIVE_DUTY >= 80
        BTFSC   STATUS, C
        BSF     PORTC_IMG, LED_HI_BIT
        GOTO    OUT_COMMIT

OUT_STOPPED:
        ; Motor STOPPED: IN1=0, IN2=0 (coast/brake), Red LED ON
        BSF     PORTC_IMG, LED_STOP_BIT

OUT_COMMIT:
        MOVF    PORTC_IMG, W        ; Single atomic write avoids RMW glitch
        MOVWF   PORTC
        RETURN

; ============================================================================
; SUBROUTINES: INTERNAL DATA EEPROM READ & WRITE (Bank 2 & Bank 3)
; ============================================================================
EEPROM_LOAD_SPEED:
        BSF     STATUS, RP1         ; Select Bank 2 (RP1=1, RP0=0)
        BCF     STATUS, RP0
        MOVLW   EEPROM_SPD_ADDR
        MOVWF   EEADR
        BSF     STATUS, RP0         ; Select Bank 3 (RP1=1, RP0=1)
        BCF     EECON1, EEPGD       ; Access Data EEPROM
        BSF     EECON1, RD          ; Trigger read
        BCF     STATUS, RP0         ; Select Bank 2
        MOVF    EEDATA, W           ; Read byte into W
        BCF     STATUS, RP1         ; Return to Bank 0
        MOVWF   BTN_DUTY

        ; Validate range (0..100%); blank EEPROM (0xFF) defaults to 50%
        MOVLW   0x65                ; 101 decimal
        SUBWF   BTN_DUTY, W         ; C = 1 if BTN_DUTY >= 101 (invalid)
        BTFSS   STATUS, C
        RETURN
        MOVLW   DEFAULT_DUTY        ; Restore safe default = 50%
        MOVWF   BTN_DUTY
        RETURN

EEPROM_SAVE_SPEED:
        MOVF    BTN_DUTY, W
        MOVWF   EE_VAL              ; Save value in Bank 0 RAM first
        BSF     STATUS, RP1         ; Select Bank 2
        BCF     STATUS, RP0
        MOVLW   EEPROM_SPD_ADDR
        MOVWF   EEADR
        BCF     STATUS, RP1         ; Bank 0 to fetch EE_VAL
        MOVF    EE_VAL, W
        BSF     STATUS, RP1         ; Bank 2 to load EEDATA
        MOVWF   EEDATA
        BSF     STATUS, RP0         ; Select Bank 3
        BCF     EECON1, EEPGD       ; Select Data EEPROM
        BSF     EECON1, WREN        ; Enable EEPROM writes
        BCF     INTCON, GIE         ; Disable interrupts during unlock sequence
        MOVLW   0x55
        MOVWF   EECON2              ; Mandatory unlock byte 1
        MOVLW   0xAA
        MOVWF   EECON2              ; Mandatory unlock byte 2
        BSF     EECON1, WR          ; Start write cycle
        BSF     INTCON, GIE         ; Re-enable interrupts
EE_WR_WAIT:
        BTFSC   EECON1, WR          ; Wait for write to complete (~4 ms)
        GOTO    EE_WR_WAIT
        BCF     EECON1, WREN        ; Disable writes for safety
        BCF     STATUS, RP0         ; Return to Bank 0
        BCF     STATUS, RP1
        RETURN

; ============================================================================
; SUBROUTINE: UPDATE_LCD
;   Line 1: "PWM: 50% DIR:CW "  (or "PWM:100% DIR:CCW")
;   Line 2: "MODE:BTN RUN    "  (or "MODE:POT STOP   ")
; ============================================================================
UPDATE_LCD:
        ; --- Line 1 (DDRAM 0x80) ---
        MOVLW   0x80
        CALL    LCD_CMD
        MOVLW   'P'
        CALL    LCD_DATA
        MOVLW   'W'
        CALL    LCD_DATA
        MOVLW   'M'
        CALL    LCD_DATA
        MOVLW   ':'
        CALL    LCD_DATA

        MOVF    ACTIVE_DUTY, W
        CALL    LCD_PRINT_3DIG      ; Prints " 50" or "100"

        MOVLW   '%'
        CALL    LCD_DATA
        MOVLW   ' '
        CALL    LCD_DATA
        MOVLW   'D'
        CALL    LCD_DATA
        MOVLW   'I'
        CALL    LCD_DATA
        MOVLW   'R'
        CALL    LCD_DATA
        MOVLW   ':'
        CALL    LCD_DATA

        BTFSC   SYS_FLAGS, F_DIR_CCW
        GOTO    LCD_DIR_CCW
        MOVLW   'C'
        CALL    LCD_DATA
        MOVLW   'W'
        CALL    LCD_DATA
        MOVLW   ' '
        CALL    LCD_DATA
        GOTO    LCD_LINE2

LCD_DIR_CCW:
        MOVLW   'C'
        CALL    LCD_DATA
        MOVLW   'C'
        CALL    LCD_DATA
        MOVLW   'W'
        CALL    LCD_DATA

        ; --- Line 2 (DDRAM 0xC0) ---
LCD_LINE2:
        MOVLW   0xC0
        CALL    LCD_CMD
        MOVLW   'M'
        CALL    LCD_DATA
        MOVLW   'O'
        CALL    LCD_DATA
        MOVLW   'D'
        CALL    LCD_DATA
        MOVLW   'E'
        CALL    LCD_DATA
        MOVLW   ':'
        CALL    LCD_DATA

        BTFSC   SYS_FLAGS, F_POT_MODE
        GOTO    LCD_MODE_POT
        MOVLW   'B'
        CALL    LCD_DATA
        MOVLW   'T'
        CALL    LCD_DATA
        MOVLW   'N'
        CALL    LCD_DATA
        GOTO    LCD_RUN_STATE

LCD_MODE_POT:
        MOVLW   'P'
        CALL    LCD_DATA
        MOVLW   'O'
        CALL    LCD_DATA
        MOVLW   'T'
        CALL    LCD_DATA

LCD_RUN_STATE:
        MOVLW   ' '
        CALL    LCD_DATA
        MOVLW   ' '
        CALL    LCD_DATA

        BTFSS   SYS_FLAGS, F_RUN
        GOTO    LCD_ST_STOP
        MOVLW   'R'
        CALL    LCD_DATA
        MOVLW   'U'
        CALL    LCD_DATA
        MOVLW   'N'
        CALL    LCD_DATA
        MOVLW   ' '
        CALL    LCD_DATA
        MOVLW   ' '
        CALL    LCD_DATA
        MOVLW   ' '
        CALL    LCD_DATA
        RETURN

LCD_ST_STOP:
        MOVLW   'S'
        CALL    LCD_DATA
        MOVLW   'T'
        CALL    LCD_DATA
        MOVLW   'O'
        CALL    LCD_DATA
        MOVLW   'P'
        CALL    LCD_DATA
        MOVLW   ' '
        CALL    LCD_DATA
        MOVLW   ' '
        CALL    LCD_DATA
        RETURN

; ============================================================================
; SUBROUTINE: LCD_PRINT_3DIG (Converts W = 0..100 into 3 ASCII chars)
;   Prints "100" for 100, or " XY" for 0..99 (suppresses leading zero on 100s)
; ============================================================================
LCD_PRINT_3DIG:
        MOVWF   BCD_ONES
        CLRF    BCD_HUND
        CLRF    BCD_TENS

        ; Check if >= 100
        MOVLW   0x64
        SUBWF   BCD_ONES, W         ; C = 1 if >= 100
        BTFSS   STATUS, C
        GOTO    BCD_TENS_LOOP
        MOVWF   BCD_ONES
        INCF    BCD_HUND, F

BCD_TENS_LOOP:
        MOVLW   0x0A
        SUBWF   BCD_ONES, W         ; W = BCD_ONES - 10; C = 1 if >= 10
        BTFSS   STATUS, C
        GOTO    BCD_PRINT_OUT
        MOVWF   BCD_ONES
        INCF    BCD_TENS, F
        GOTO    BCD_TENS_LOOP

BCD_PRINT_OUT:
        MOVF    BCD_HUND, W
        BTFSC   STATUS, Z           ; If hundreds == 0, print space
        GOTO    BCD_SPC_HUND
        ADDLW   '0'
        CALL    LCD_DATA
        GOTO    BCD_PRINT_TENS
BCD_SPC_HUND:
        MOVLW   ' '
        CALL    LCD_DATA

BCD_PRINT_TENS:
        MOVF    BCD_TENS, W
        ADDLW   '0'
        CALL    LCD_DATA
        MOVF    BCD_ONES, W
        ADDLW   '0'
        CALL    LCD_DATA
        RETURN

; ============================================================================
; SUBROUTINES: 16x2 LCD 4-BIT DRIVER (RD2=RS, RD3=EN, RD4-RD7=D4-D7)
; ============================================================================
LCD_INIT:
        CALL    DELAY_50MS          ; Wait > 40 ms after VDD rises
        MOVLW   0x30
        CALL    LCD_NIBBLE_CMD
        CALL    DELAY_5MS
        MOVLW   0x30
        CALL    LCD_NIBBLE_CMD
        CALL    DELAY_2MS
        MOVLW   0x30
        CALL    LCD_NIBBLE_CMD
        CALL    DELAY_2MS
        MOVLW   0x20                ; Switch LCD to 4-bit interface
        CALL    LCD_NIBBLE_CMD
        CALL    DELAY_2MS

        MOVLW   0x28                ; Function Set: 4-bit, 2 lines, 5x8 font
        CALL    LCD_CMD
        MOVLW   0x0C                ; Display ON, Cursor OFF, Blink OFF
        CALL    LCD_CMD
        MOVLW   0x06                ; Entry Mode: Auto-increment cursor right
        CALL    LCD_CMD
        MOVLW   0x01                ; Clear Display
        CALL    LCD_CMD
        CALL    DELAY_2MS
        RETURN

LCD_CMD:
        MOVWF   LCD_TEMP
        ANDLW   0xF0                ; High nibble first (RS = 0)
        CALL    LCD_NIBBLE_CMD
        SWAPF   LCD_TEMP, W
        ANDLW   0xF0                ; Low nibble second (RS = 0)
        CALL    LCD_NIBBLE_CMD
        CALL    DELAY_2MS
        RETURN

LCD_DATA:
        MOVWF   LCD_TEMP
        ANDLW   0xF0                ; High nibble first (RS = 1)
        IORLW   0x04                ; Set RD2 (RS = 1)
        CALL    LCD_NIBBLE_CMD
        SWAPF   LCD_TEMP, W
        ANDLW   0xF0                ; Low nibble second (RS = 1)
        IORLW   0x04                ; Set RD2 (RS = 1)
        CALL    LCD_NIBBLE_CMD
        CALL    DELAY_2MS
        RETURN

LCD_NIBBLE_CMD:
        MOVWF   PORTD               ; Place data nibble + RS on PORTD
        BSF     PORTD, LCD_EN_BIT   ; Pulse EN high
        NOP
        NOP
        BCF     PORTD, LCD_EN_BIT   ; Latch on falling edge of EN
        RETURN

; ============================================================================
; SUBROUTINES: SOFTWARE TIMING DELAYS (@ Fosc = 4 MHz, 1 TCY = 1 us)
; ============================================================================
DELAY_2MS:
        MOVLW   0x03
        MOVWF   DLY_1
D2_OUTER:
        MOVLW   0xDD
        MOVWF   DLY_2
D2_INNER:
        DECFSZ  DLY_2, F
        GOTO    D2_INNER
        DECFSZ  DLY_1, F
        GOTO    D2_OUTER
        RETURN

DELAY_5MS:
        MOVLW   0x07
        MOVWF   DLY_1
D5_OUTER:
        MOVLW   0xEE
        MOVWF   DLY_2
D5_INNER:
        DECFSZ  DLY_2, F
        GOTO    D5_INNER
        DECFSZ  DLY_1, F
        GOTO    D5_OUTER
        RETURN

DELAY_50MS:
        MOVLW   0x41
        MOVWF   DLY_1
D50_OUTER:
        MOVLW   0xFF
        MOVWF   DLY_2
D50_INNER:
        DECFSZ  DLY_2, F
        GOTO    D50_INNER
        DECFSZ  DLY_1, F
        GOTO    D50_OUTER
        RETURN

        END
